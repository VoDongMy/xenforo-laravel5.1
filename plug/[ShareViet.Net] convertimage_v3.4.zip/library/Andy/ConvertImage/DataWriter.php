<?php

class Andy_ConvertImage_DataWriter extends XFCP_Andy_ConvertImage_DataWriter
{
	public function save()
	{		
		// call parent
		parent::save();
		
		// check for ImageMagick option
		$getOption = XenForo_Application::get('options')->imageLibrary['class'];
		
		// get options from Admin CP -> Options -> Convert Image -> Temporary Image Directory   
		$temporaryImageDirectory = XenForo_Application::get('options')->convertImageTemporaryImageDirectory;		
	
		// verify ImageMagick is enabled
		if ($getOption != 'imPecl')
		{			
			XenForo_Error::logException(new XenForo_Exception("ImageMagick is not enabled."));
			return true;
		}
		
		// verify temporary image directory is set
		if ($temporaryImageDirectory == '')
		{
			XenForo_Error::logException(new XenForo_Exception("Temporary image directory is not set."));
			return true;
		}
		
		// get options from Admin CP -> Options -> Convert Image -> Env Path   
		$envPath = XenForo_Application::get('options')->convertImageEnvPath;
		
		// create convertPath and identifyPath variables
		if ($envPath == '')
		{
			$convertPath = '/usr/bin/convert';
			$identifyPath = '/usr/bin/identify';
		}
		else
		{
			$convertPath = $envPath . 'convert';
			$identifyPath = $envPath . 'identify';
		}
		
		// define variables
		$updateRequired = '';	
		$newMessage = '';
		$attachCount = '';	
		$done = '';
		
		// get current message
		$currentMessage = $this->get('message');				
		
		// check for [IMG]link[/IMG]
		if (preg_match_all("/\[IMG\](.+?)\[\/IMG\]/i", $currentMessage, $out))
		{	
			//#####################################
			// start loop
			//#####################################		
							
			for ($i=0; $i < count($out[1]); $i++)
			{	
				//#####################################
				// An error will stop the loop from
				// converting any more images in this post.
				//#####################################
				
				if ($done != 'yes')
				{
					//#####################################
					// download image into temporary directory
					//#####################################
					
					// get imglink
					$imglink = $out[1][$i];
					
					// declare variables
					$is_gif = false;
					$is_jpg = false;
					$is_png = false;					
					
					// check for proper extension               
					if (!preg_match("/\.(gif|png|jpg|jpeg|jpe)/", strtolower($imglink)))
					{						
						$im = @imagecreatefromgif($imglink);
						if ($im)
						{
							$is_gif = true;
						}
						
						$im = @imagecreatefromjpeg($imglink);
						if ($im)
						{
							$is_jpg = true;
						}
						
						$im = @imagecreatefrompng($imglink);
						if ($im)
						{
							$is_png = true;
						}														
						
						if ($is_gif == false AND $is_jpg == false AND $is_png == false)
						{
							$done = 'yes';
						}
					}
					
					// only contunue if we have a valid image
					if ($done != 'yes') 
					{
						// encode spaces
						$imglink = str_replace(' ', '%20', $imglink);
						
						// define full path of download
						$tempFullPath = $temporaryImageDirectory . 'convert' . '_' . rand();
						
						if (!file_exists($tempFullPath))
						{
							touch($tempFullPath); // create blank file
							chmod($tempFullPath,0777);
						}
				
						$ch = curl_init($imglink);
						$fp = fopen($tempFullPath, "w");
					
						curl_setopt($ch, CURLOPT_FILE, $fp);
						curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
						curl_setopt($ch, CURLOPT_HEADER, 0);
						curl_setopt($ch, CURLOPT_TIMEOUT, 5);
						curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
						
						// get options from Admin CP -> Options -> Convert Image -> Follow Redirects
						$followRedirects = XenForo_Application::get('options')->convertImageFollowRedirects;				
		
						// set if followRedirects is enabled
						if ($followRedirects)	
						{		
							curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
						} 
						
						// execute curl
						curl_exec($ch);
						
						// set done variable if there was an error
						if (curl_errno($ch) > 0)
						{
							$done = 'yes';
						}				
						
						// close the file 
						fclose($fp);
					
						//#####################################
						// make sure we have a valid image
						//#####################################
		
						// get dimensions - supress error message
						@list($width, $height) = getimagesize($tempFullPath);			
					
						// if not image abort
						if (is_null($width))
						{
							$done = 'yes';	
						}
					}
					
					// only contunue if we have a valid image
					if ($done != 'yes') 
					{															
						//#####################################
						// resize image
						//#####################################
						
						// get options from Admin CP -> Options -> Attachments -> Maximum Attachment Image Dimensions
						$attachmentMaxWidth = XenForo_Application::get('options')->attachmentMaxDimensions['width'];	
						
						// get options from Admin CP -> Options -> Attachments -> Maximum Attachment Image Dimensions
						$attachmentMaxHeight = XenForo_Application::get('options')->attachmentMaxDimensions['height'];										
						
						// resize if width exceeds maximum allowed
						if ($width > $attachmentMaxWidth)
						{
							exec("$convertPath $tempFullPath -resize $attachmentMaxWidth\x $tempFullPath");
						
							// get new image size
							list($width, $height) = getimagesize($tempFullPath);
						}	
						
						// resize if height exceeds maximum allowed
						if ($height > $attachmentMaxHeight)
						{
							// resize only if width or height exceed maximum - (use the '\>' flag)
							exec("$convertPath $tempFullPath -resize x$attachmentMaxHeight $tempFullPath");
							
							// get new image size
							list($width, $height) = getimagesize($tempFullPath);
						}
						
						//#####################################
						// check filesize
	
						// get file size in bytes
						$filesize = filesize($tempFullPath);
						
						// get options from Admin CP -> Options -> Attachments -> Maximum Attachment File Size (KB)   
						$maxFileSize = XenForo_Application::get('options')->attachmentMaxFileSize;
						
						// convert to bytes
						$maxFileSize = $maxFileSize * 1024;			
		
						// check filesize
						if ($filesize > $maxFileSize)
						{
							$done = 'yes';	
						}
	
						// only contunue if filesize not exceeded
						if ($done != 'yes') 
						{
							//#####################################
							// Begin creating the attachment
							// prepare data for SQL query.
							//#####################################

							$currentUserId = $this->get('user_id');				
							$uploadDate = time();
							$basename = basename($imglink);
							
							if ($is_gif)
							{
								$basename = $basename . '.gif';
							}
							
							if ($is_jpg)
							{
								$basename = $basename . '.jpg';
							}
							
							if ($is_png)
							{
								$basename = $basename . '.png';
							}														

							//#####################################
							// Remove any characters after the
							// extension.
							//#####################################							
							
							// check .gif
							$pos1 = stripos($basename, '.gif');
							
							if (is_numeric($pos1))
							{
								$pos1 = $pos1 + 4;	
								$basename = substr($basename, 0, $pos1);
							}
							
							// check .png
							$pos1 = stripos($basename, '.png');
							
							if (is_numeric($pos1))
							{								
								$pos1 = $pos1 + 4;
								$basename = substr($basename, 0, $pos1);
							}
							
							// check .jpg
							$pos1 = stripos($basename, '.jpg');
							
							if (is_numeric($pos1))
							{								
								$pos1 = $pos1 + 4;
								$basename = substr($basename, 0, $pos1);
							}
							
							// check .jpeg
							$pos1 = stripos($basename, '.jpeg');
							
							if (is_numeric($pos1))
							{								
								$pos1 = $pos1 + 5;
								$basename = substr($basename, 0, $pos1);
							}
							
							// check .jpe
							$pos1 = stripos($basename, '.jpe');
							
							if (is_numeric($pos1))
							{								
								$pos1 = $pos1 + 4;
								$basename = substr($basename, 0, $pos1);
							}																										
							
							// make sure basename fits 100 character limit
							if (strlen($basename) > 100)
							{
								$strlen = strlen($basename);
								$pos_start = $strlen - 100;
								$basename = substr($basename,$pos_start);
							}
							
							$filesize = filesize($tempFullPath);
							$filehash = hash_file('md5', $tempFullPath);
							
							$currentPostId = $this->get('post_id');
							
							//#####################################
							// run SQL query (attachment_data)
							//#####################################			
							
							$db = XenForo_Application::get('db');
			
							$db->query("
								INSERT INTO xf_attachment_data
									(user_id, upload_date, filename, file_size, file_hash, width, height, thumbnail_width, thumbnail_height, attach_count)
								VALUES
									(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
							", array($currentUserId, $uploadDate, $basename, $filesize, $filehash, $width, $height, '0', '0', '1'));
							
							// get the new data_id number (auto incremented) 
							$dataId = $db->lastInsertId();
							
							//#####################################
							// run SQL query (attachment)
							//#####################################							
							
							$db->query("
								INSERT INTO xf_attachment
									(data_id, content_type, content_id, attach_date, temp_hash, unassociated, view_count)
								VALUES
									(?, ?, ?, ?, ?, ?, ?)
							", array($dataId, 'post', $currentPostId, $uploadDate, '', '0', '0'));
							
							// get the new attachment_id number (auto incremented) 
							$attachmentId = $db->lastInsertId();
							
							//#####################################
							// define last folder name 
							// 0-999 are stored in the 0 directory 
							// 1000-1999 stored in the 1 directory etc 
							//#####################################
							
							$lastfolder = floor($dataId / 1000);
							
							//#####################################
							// define path variables
							//#####################################
							
							// get internal_data path
							$internalDataPath = XenForo_Helper_File::getInternalDataPath();
							
							// get data path					
							$externalDataPath = XenForo_Helper_File::getExternalDataPath();						
							
							// define full path
							$attachmentFullPath = $internalDataPath . '/attachments/' . $lastfolder . '/' . $dataId . '-' . $filehash . '.data';
					
							//#####################################
							// Create new internal_data and data
							// directories if they don't exsist.
							//#####################################
							
							$directory = $internalDataPath . '/attachments/' . $lastfolder;
							
							if (!file_exists($directory))
							{
								// needed to make 0777
								$old_umask = umask(0);
								
								// make directories
								mkdir($externalDataPath . '/attachments/' . $lastfolder, 0777);
								mkdir($internalDataPath . '/attachments/' . $lastfolder, 0777);
								
								// create path for /data/index.html file
								$indexpath = $externalDataPath . '/attachments/' . $lastfolder . '/index.html';
								touch($indexpath); // Create index.html
								chmod($indexpath,0666);	
								
								// create path for /internal_data/index.html file
								$indexpath = $internalDataPath . '/attachments/' . $lastfolder . '/index.html';
								touch($indexpath); // Create index.html
								chmod($indexpath,0666);			
							}
									
							//#####################################
							// Copy image from temporary directory 
							// to attachment directory and delete
							// temporary image.
							//#####################################
							
							// prepare new file
							if (!file_exists($attachmentFullPath))
							{
								touch($attachmentFullPath); // Create blank file
								chmod($attachmentFullPath,0777);
							}
							
							// get image from temporary directory
							$tempImage = file_get_contents($tempFullPath);
										
							// save image to attachment directory
							file_put_contents($attachmentFullPath, $tempImage); 
							
							//#####################################
							// create thumbnail
							//#####################################
							
							// get options from Admin CP -> Options -> Attachments -> Attachment Thumbnail Dimensions
							$attachmentThumbnailDimensions = XenForo_Application::get('options')->attachmentThumbnailDimensions;
					
							$thumbpath = $externalDataPath . '/attachments/' . $lastfolder . '/' . $dataId . '-' . $filehash . '.jpg';
								
							if (!file_exists($thumbpath))
							{
								touch($thumbpath); // Create blank file
								chmod($thumbpath,0777);
							}
							
							// check if animated gif
							$isAnimation = exec("$identifyPath -format '%n' $attachmentFullPath");	
							
							if ($isAnimation > 1)
							{	
								// only resize if width or height is larger than 100px
								if ($width >= $attachmentThumbnailDimensions OR $height >= $attachmentThumbnailDimensions)
								{
									$firstFrame = $attachmentFullPath . '[0]';
									exec("$convertPath $firstFrame -coalesce -background white -flatten -resize $attachmentThumbnailDimensions x $attachmentThumbnailDimensions $thumbpath");
								}
								
								// no resize required
								if ($width < $attachmentThumbnailDimensions AND $height < $attachmentThumbnailDimensions)
								{
									exec("cp $attachmentFullPath $thumbpath");
								}
							}
							else
							{
								exec("$convertPath $attachmentFullPath -background white -flatten -resize $attachmentThumbnailDimensions x $attachmentThumbnailDimensions $thumbpath");
							}
							
							//#####################################
							// update attachment_data table with dimensions
							//#####################################
							
							// get dimensions of thumbnail
							@list($width, $height) = getimagesize($thumbpath);
							
							// assign value if image width or height could not be read
							if (is_null($width) OR is_null($height))
							{
								$width = 0;
								$height = 0;
							}
							
							$db->query('
							UPDATE xf_attachment_data SET
								thumbnail_width = ?
								WHERE data_id = ?
							', array($width, $dataId));
							
							$db->query('
							UPDATE xf_attachment_data SET
								thumbnail_height = ?
								WHERE data_id = ?
							', array($height, $dataId));				
												
							//#####################################
							// update message with [ATTACH] tags
							//#####################################
							
							// get options from Admin CP -> Options -> Convert Image -> Insert Thumbnail    
							$insertThumbnail = XenForo_Application::get('options')->insertThumbnail;
							
							// insert attach code
							if ($insertThumbnail == 1)
							{
								$attachcode = '[ATTACH]' . $attachmentId . '[/ATTACH]';	
							}
							else
							{
								$attachcode = '[ATTACH=full]' . $attachmentId . '[/ATTACH]';	
							}
							
							// get posStart
							if ($newMessage == '')
							{
								// calulate start position
								$posStart = stripos($currentMessage, '[IMG]');
							}
							else
							{
								// calulate start position
								$posStart = stripos($newMessage, '[IMG]');
							}
							
							// calulate posEnd position	
							$posEnd = strlen($imglink) + 11;
							
							// update newMessage
							if ($newMessage == '')
							{
								// create new message
								$newMessage = substr_replace($currentMessage, $attachcode, $posStart, $posEnd);
							}
							else
							{
								// create new message
								$newMessage = substr_replace($newMessage, $attachcode, $posStart, $posEnd);
							}
							
							//#####################################
							// update optional log file
							//#####################################
							
							// declare variable
							$convertImageLogFile = '';
							
							// get options from Admin CP -> Options -> Convert Image -> Log File   
							$convertImageLogFile = XenForo_Application::get('options')->convertImageLogFile;					
							
							if ($convertImageLogFile != '')
							{
								// verify log file exists
								if (file_exists($convertImageLogFile))
								{
									
									// adjust for local timezone
									$dateline = time() + XenForo_Locale::getTimeZoneOffset();
									
									// format date
									$formatedDate = date("m/d/y h:ia", $dateline);
									
									// prepare data
									$data = $formatedDate . ' / Post ' . $currentPostId . ' / ' . $imglink . '
';
									// update log file
									$handle = fopen($convertImageLogFile, 'a');
									fwrite($handle, $data);
									fclose($handle);
								}
							}
							
							//#####################################
							// set $updateRequired flag
							//#####################################														
							
							$updateRequired = 'yes';
							$attachCount = $attachCount + 1;
						}
					}
				}
			}
		}
		
		if ($updateRequired == 'yes')
		{			
			//#####################################
			// update xf_post
			//#####################################			
			
			$db->query('
			UPDATE xf_post SET
				message = ?
				WHERE post_id = ?
			', array($newMessage, $currentPostId));				
			
			$db->query('
			UPDATE xf_post SET
				attach_count = ?
				WHERE post_id = ?
			', array($attachCount, $currentPostId));							
			
			//#####################################
			// delete xf_bb_code_parse_cache
			//#####################################		
			
			$db->query('
				DELETE FROM xf_bb_code_parse_cache
				WHERE content_id = ?
			', $currentPostId);	
			
			//########################################
			// this query is used to update 
			// xf_search_index and ElasticSearch index
			
			// run query
			$data = $db->fetchRow("
			SELECT xf_thread.node_id, 
			xf_thread.thread_id, 
			xf_thread.title, 
			xf_post.message, 
			xf_post.post_date, 
			xf_post.user_id
			FROM xf_post
			INNER JOIN xf_thread ON xf_thread.thread_id = xf_post.thread_id 
			WHERE xf_post.post_id = ?
			", $currentPostId);
			
			// make safe for query
			$data['message'] = addslashes($data['message']);				
			
			//#####################################
			// update xf_search_index
			//#####################################				

			// if ElasticSearch is NOT enabled
			if (!XenForo_Application::get('options')->enableElasticsearch)
			{				
				// run query
				$db->query('
					UPDATE xf_search_index SET
						message = "' . $data['message'] . '"
					WHERE content_type = "post"
					AND content_id = ?
				', $currentPostId);
			}
			
			//#####################################
			// update ElasticSearch post index
			//#####################################
			
			// if ElasticSearch is enabled
			if (XenForo_Application::get('options')->enableElasticsearch)
			{				
				// get ElasticSearch index name
				$indexName = XenES_Api::getInstance()->getIndex();		
				
				// define variables
				$contentType = 'post';
				$contentId = $currentPostId;
				
				// define record data
				$record = array(
					'node' => $data['node_id'],
					'thread' => $data['thread_id'],
					'title' => $data['title'], 
					'message' => $data['message'],
					'date' => $data['post_date'],
					'user' => $data['user_id'],
					'discussion_id' => $currentPostId
				);
	
				// update ElasticSearch index
				XenES_Api::index($indexName, $contentType, $contentId, $record);
			}
		}
	}
}