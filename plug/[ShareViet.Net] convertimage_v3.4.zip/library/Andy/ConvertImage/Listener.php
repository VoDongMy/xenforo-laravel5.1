<?php

class Andy_ConvertImage_Listener
{	
	public static function loadClassDatawriter($class, array &$extend)
	{
		$extend[] = 'Andy_ConvertImage_DataWriter';
	} 
}