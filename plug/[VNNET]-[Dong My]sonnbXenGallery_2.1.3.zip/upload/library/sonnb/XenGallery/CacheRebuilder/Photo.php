<?php

/**
 * Product: sonnb - XenGallery
 * Version: 1.1.3
 * Date: 28th September 2013
 * Author: sonnb
 * Website: www.sonnb.com
 * License: One license is valid for only one nominated domain.
 * You might not copy or redistribute this addon.
 * Any action to public or redistribute must be authorized from author
 */

class sonnb_XenGallery_CacheRebuilder_Photo extends sonnb_XenGallery_CacheRebuilder_Content
{

}